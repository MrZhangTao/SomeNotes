from flask_migrate import Migrate, upgrade
from app import create_app, db
from app.models import User, Follow, Role, Permission, Post, Comment
import os
from app import fake

app = create_app(os.getenv('FLASK_CONFIG') or 'default')
migrate = Migrate(app, db)

app.app_context().push()
db.create_all()
Role.insert_roles()
User.add_self_follows()
fake.users(10)
fake.posts(10)
app.run()

